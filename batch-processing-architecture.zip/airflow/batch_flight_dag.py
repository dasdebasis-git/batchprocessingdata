
from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

with DAG('batch_flight_pipeline', start_date=datetime(2023, 1, 1), schedule_interval='@quarterly', catchup=False) as dag:
    process = BashOperator(
        task_id='run_spark_processing',
        bash_command='spark-submit /spark/batch_processing.py'
    )
